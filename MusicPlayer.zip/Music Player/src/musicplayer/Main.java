package musicplayer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.PrimitiveIterator.OfDouble;
import java.util.Scanner;

import javax.management.loading.PrivateClassLoader;
import javax.naming.ldap.Rdn;

public class Main {

	private static ArrayList<Album> albums = new ArrayList<>();
	
	public static void main(String[] args) {
	
		
		
		Album album = new Album("RED", "Taylor Swift");
		
		album.addSong("State Of Grace ", 4.55);
		album.addSong("Red ", 3.43);
		album.addSong("Treacherous ", 4.03);
		album.addSong("I Knew You Were Trouble ", 3.40);
		album.addSong("I Almost Do ", 4.05);
		album.addSong("Better Man ", 4.57);
		album.addSong("Babe ", 3.44);
		album.addSong("The Very Fisrt Night ", 3.20);
		album.addSong("All Too Well ", 10.13);
		albums.add(album);
		
		
		album = new Album ("Butterfly", "Mariah Carey");
		
		album.addSong("Honey",5.00);
		album.addSong("Butterfly", 4.34);
		album.addSong("My All", 3.51);
		album.addSong("The Roof", 5.14);
		album.addSong("Outside", 4.46);
		albums.add(album);
		
		LinkedList<Song> playList_1 = new LinkedList<>();
		
		albums.get(0).addToPlayList("Red",playList_1);
		albums.get(0).addToPlayList("All Too Well",playList_1);
		albums.get(1).addToPlayList("My All",playList_1);
		albums.get(1).addToPlayList("The Roof",playList_1);
		
		play(playList_1);
		
		
	}

	private static void play(LinkedList<Song> playList) {
		Scanner scanner = new Scanner(System.in);
		boolean quit = false;
		boolean forward = true;
		ListIterator<Song> listIterator = playList.listIterator();
		
		if (playList.size() == 0) {
			System.out.println("This playlist has no song");
		} else {
			System.out.println("Now playing " + listIterator.next().toString());
			printMenu();
		}
		
		while(!quit) {
			int action = scanner.nextInt();
			scanner.nextLine();
			
			switch (action) {
				case 0:
					System.out.println("Playlist complete");
					quit = true;
					break;
				case 1:
					if (!forward) {
						if (listIterator.hasNext()) {
							listIterator.next();
						}
						forward = true;
						
					}
					if (listIterator.hasNext()) {
						System.out.println("Now playing" + listIterator.next().toString());
					} else {
						System.out.println("no song available, reached out to the end of the list");
						forward = false;
					}
					break;
				
				case 2:
					if (forward) {
						if (listIterator.hasPrevious()) {
							listIterator.previous();
						}
						forward = false;
					}
					if (listIterator.hasPrevious()) {
						System.out.println("Now playing" + listIterator.previous().toString());
						
					} else {
						System.out.println("this is the first song");
						forward = false;
					}
					break;
				case 3:
					if (forward) {
						if (listIterator.hasPrevious()) {
							System.out.println("Now playing" + listIterator.previous().toString());
							forward = false;
							
						} else {
							System.out.println("this is the start od the list");
						}
					}else {
						if(listIterator.hasNext()) {
							System.out.println("Now playing" + listIterator.next().toString());
							forward = true;
						}else {
							System.out.println("you reached to the end of the list");
						}
					}
					break;
					
				case 4:
					printList(playList);
					break;
				case 5:
					printMenu();
					break;
				case 6:
					if (playList.size() >0) {
						listIterator.remove();
						if (listIterator.hasNext()) {
							System.out.println("Now playing" + listIterator.previous().toString());
						}
						else {
							if(listIterator.hasPrevious()) {
								System.out.println("Now playing" + listIterator.previous().toString());
							}
							
						}
					}
					
					
					
			}
			
		}
		
	}
	
	private static void printMenu() {
		System.out.println("Available options\n press");
		System.out.println("0 - to quit\n" + 
		"1 - to play next song\n" +
				"2 - to play previous song\n" +
		"3 - to replay the current song\n" +
				"4 - list of all songs\n" +
		"5 - print all available options\n" +
				"6 - delete current song");
		
	}
	
	private static void printList(LinkedList<Song> playlist) {
		Iterator<Song> iterator = playlist.iterator();
		System.out.println("---------------------------------");
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
			
		}
		
		System.out.println("---------------------------------");
	}
}
